<template>
  <q-page class="flex flex-center">
    <img src="~assets/crea_logo_marcadagua-minerva.png" >
    <q-icon name="trophy"/>
  </q-page>
</template>

<script>
export default {
  name: 'Home'
}
</script>
