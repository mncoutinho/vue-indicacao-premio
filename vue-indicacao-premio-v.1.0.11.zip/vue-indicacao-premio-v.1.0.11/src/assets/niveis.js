export default [
  {value: 'DOUTORADO', label: 'DOUTORADO'},
  {value: 'MESTRADO', label: 'MESTRADO'},
  {value: 'GRADUAÇÃO', label: 'GRADUAÇÃO'},
  {value: 'TÉCNICO', label: 'TÉCNICO'}
]
