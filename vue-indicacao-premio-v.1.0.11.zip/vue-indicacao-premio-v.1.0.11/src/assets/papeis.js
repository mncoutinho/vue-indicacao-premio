export default [
  {value: '1', label: 'Autor'},
  {value: '2', label: 'Avaliador'},
  {value: '3', label: 'Coorientador'},
  {value: '4', label: 'Orientador'},
  {value: '5', label: 'Comissão de Seleção'}
]
