export default [
  {
    value: 1,
    label: 'RESIDENCIAL'
  },
  {
    value: 2,
    label: 'COMERCIAL'
  },
  {
    value: 3,
    label: 'POSTAL'
  },
  {
    value: 4,
    label: 'OFICIAL'
  },
  {
    value: 5,
    label: 'MATRIZ'
  },
  {
    value: 6,
    label: 'FILIAL'
  },
  {
    value: 7,
    label: 'CONTRATANTE'
  },
  {
    value: 8,
    label: 'OBRA/SERVIÇO'
  },
  {
    value: 9,
    label: 'VISTO'
  }
]
