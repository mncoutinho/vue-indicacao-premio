export default class Participante {
  constructor (idPremio) {
    this.idPremio = idPremio
  }
  id = null
  idPremio = ''
  pessoa = { id: null, cpf: '', nome: '', tipo: '' }
  email = ''
  telefone = ''
  celular = ''
  papel = ''
  idEndereco = ''
  idTitulo= ''
  titulo = ''
}
