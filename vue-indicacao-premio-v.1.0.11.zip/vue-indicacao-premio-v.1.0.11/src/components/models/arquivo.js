export default class Arquivo {
  id = ''
  nomeOriginal = ''
  uri = ''
  modulo = 'INSTITUICAO'
  privado = true
}
