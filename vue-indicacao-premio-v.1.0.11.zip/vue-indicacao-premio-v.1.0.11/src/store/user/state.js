export default {
  token: localStorage.getItem('user-token') || '',
  status: '',
  user: {},
  listaMenu: []
}
