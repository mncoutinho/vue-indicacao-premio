export default {
  premio: {}
}
