export const setPremio = (state, value) => {
  state.premio = value
}
