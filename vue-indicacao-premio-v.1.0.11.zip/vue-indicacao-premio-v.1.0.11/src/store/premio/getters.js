export const getPremio = (state) => {
  return state.premio
}

export const getListUFs = (state) => {
  return state.listUFs
}
